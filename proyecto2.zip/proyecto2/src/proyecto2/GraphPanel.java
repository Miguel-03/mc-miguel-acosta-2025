/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GraphPanel extends JPanel {
    private ArrayList<Double> xList, yList;
    private PolynomialRegression regression;

    public void setData(ArrayList<Double> xList, ArrayList<Double> yList, PolynomialRegression regression) {
        this.xList = xList;
        this.yList = yList;
        this.regression = regression;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (xList == null || yList == null) return;

        int w = getWidth();
        int h = getHeight();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);

        double minX = xList.stream().min(Double::compare).orElse(0.0);
        double maxX = xList.stream().max(Double::compare).orElse(1.0);
        double minY = yList.stream().min(Double::compare).orElse(0.0);
        double maxY = yList.stream().max(Double::compare).orElse(1.0);

        double scaleX = w / (maxX - minX);
        double scaleY = h / (maxY - minY);

        g.setColor(Color.RED);
        for (int i = 0; i < xList.size(); i++) {
            int x = (int) ((xList.get(i) - minX) * scaleX);
            int y = h - (int) ((yList.get(i) - minY) * scaleY);
            g.fillOval(x - 3, y - 3, 6, 6);
        }

        if (regression != null) {
            g.setColor(Color.BLUE);
            int prevX = 0, prevY = 0;
            for (int i = 0; i < w; i++) {
                double x = minX + (i / scaleX);
                double y = regression.predict(x);
                int px = i;
                int py = h - (int) ((y - minY) * scaleY);
                if (i > 0)
                    g.drawLine(prevX, prevY, px, py);
                prevX = px;
                prevY = py;
            }
        }
    }
}
