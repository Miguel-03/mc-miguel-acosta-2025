/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import java.util.ArrayList;

public class PolynomialRegression {
    private final ArrayList<Double> x;
    private final ArrayList<Double> y;
    private final int degree;
    private double[] coefficients;

    public PolynomialRegression(ArrayList<Double> x, ArrayList<Double> y, int degree) {
        this.x = x;
        this.y = y;
        this.degree = degree;
    }

    public void calculate() {
        int n = x.size();
        int m = degree;

        double[][] X = new double[m + 1][m + 1];
        double[] Y = new double[m + 1];

        for (int row = 0; row <= m; row++) {
            for (int col = 0; col <= m; col++) {
                X[row][col] = 0;
                for (int i = 0; i < n; i++) {
                    X[row][col] += Math.pow(x.get(i), row + col);
                }
            }

            Y[row] = 0;
            for (int i = 0; i < n; i++) {
                Y[row] += y.get(i) * Math.pow(x.get(i), row);
            }
        }

        coefficients = gaussianElimination(X, Y);
    }

    private double[] gaussianElimination(double[][] A, double[] b) {
        int n = b.length;
        for (int p = 0; p < n; p++) {
            int max = p;
            for (int i = p + 1; i < n; i++)
                if (Math.abs(A[i][p]) > Math.abs(A[max][p]))
                    max = i;

            double[] temp = A[p];
            A[p] = A[max];
            A[max] = temp;

            double t = b[p];
            b[p] = b[max];
            b[max] = t;

            for (int i = p + 1; i < n; i++) {
                double alpha = A[i][p] / A[p][p];
                b[i] -= alpha * b[p];
                for (int j = p; j < n; j++) {
                    A[i][j] -= alpha * A[p][j];
                }
            }
        }

        double[] solution = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double sum = b[i];
            for (int j = i + 1; j < n; j++) {
                sum -= A[i][j] * solution[j];
            }
            solution[i] = sum / A[i][i];
        }

        return solution;
    }

    public double predict(double xVal) {
        double result = 0;
        for (int i = 0; i < coefficients.length; i++) {
            result += coefficients[i] * Math.pow(xVal, i);
        }
        return result;
    }

    public String getEquation() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < coefficients.length; i++) {
            sb.append(String.format("%.4f", coefficients[i]));
            if (i > 0) sb.append("x^").append(i);
            if (i < coefficients.length - 1) sb.append(" + ");
        }
        return sb.toString();
    }

    public double computeRSquared() {
        double meanY = 0;
        for (double v : y) meanY += v;
        meanY /= y.size();

        double ssTot = 0, ssRes = 0;
        for (int i = 0; i < x.size(); i++) {
            double yi = y.get(i);
            double fi = predict(x.get(i));
            ssTot += Math.pow(yi - meanY, 2);
            ssRes += Math.pow(yi - fi, 2);
        }

        return 1 - (ssRes / ssTot);
    }
}