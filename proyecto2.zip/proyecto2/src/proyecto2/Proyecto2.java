/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;



public class Proyecto2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("Regresión Polinomial");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextArea inputArea = new JTextArea("Ingresa al menos 6 puntos (formato: x y):\n");
        JButton runButton = new JButton("Ejecutar Regresión");
        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);

        GraphPanel graphPanel = new GraphPanel();

        runButton.addActionListener(e -> {
            ArrayList<Double> xList = new ArrayList<>();
            ArrayList<Double> yList = new ArrayList<>();

            String[] lines = inputArea.getText().split("\\n");
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                try {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length != 2) continue;
                    double x = Double.parseDouble(parts[0]);
                    double y = Double.parseDouble(parts[1]);
                    xList.add(x);
                    yList.add(y);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(frame, "Formato inválido en línea: " + line);
                    return;
                }
            }

            if (xList.size() < 6) {
                JOptionPane.showMessageDialog(frame, "Se requieren al menos 6 puntos.");
                return;
            }

            resultArea.setText("");
            graphPanel.setData(xList, yList, null);

            for (int degree = 1; degree <= 10; degree++) {
                PolynomialRegression regression = new PolynomialRegression(xList, yList, degree);
                regression.calculate();

                double r2 = regression.computeRSquared();
                resultArea.append("Grado " + degree + ": f(x) = " + regression.getEquation() + "\n");
                resultArea.append("R² = " + String.format("%.4f", r2) + "\n\n");

                if (r2 >= 0.95) {
                    graphPanel.setData(xList, yList, regression);
                    graphPanel.repaint();
                    break;
                }
            }
        });

        frame.setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(new JScrollPane(inputArea), BorderLayout.CENTER);
        topPanel.add(runButton, BorderLayout.EAST);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                topPanel,
                new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(resultArea), graphPanel));

        splitPane.setDividerLocation(200);
        frame.add(splitPane);
        frame.setVisible(true);
    }
}